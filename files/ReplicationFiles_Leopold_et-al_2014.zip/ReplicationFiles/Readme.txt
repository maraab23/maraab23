---------------------------------------------------------------------------------------------------

Replication files for the article

	Leopold, Thomas, Raab, Marcel, & Engelhardt, Henriette (2014): The Transition to Parent Care: Costs, Commitments, and Caregiver Selection Among Children.
		Journal of Marriage and Family 76(2): 300-318.

---------------------------------------------------------------------------------------------------

This zip-archive includes the Stata code to replicate the results presented in the paper. 

Before you run the code, you have to download the RAND HRS files listed below. 
You might also need to install some Stata ado files. 

---------------------------------------------------------------------------------------------------

Follow these steps to replicate the results:
	1. Unzip "ReplicationFiles.zip"
	2. Register as a HRS data user (http://hrsonline.isr.umich.edu/index.php?p=reg)
	3. Download the following RAND HRS Files
		- The RAND HRS Data (Version L): rndhrs_l.dta 
			Save to folder "00_HRS/01_RAND"
		- The RAND HRS Family Data (Version B): rndfamk_b.dta 
			Save to folder "00_HRS/02_RAND_Family"
		- The RAND HRS Family Data (Version B): rndfamr_b.dta 
			Save to folder "00_HRS/02_RAND_Family"
	4. Open the do-file "00_master.do". You find this file in the folder "01_do-files"
	5. Customize your path for the global macro "workingDir"
	6. Run "00_master.do" 
*/

---------------------------------------------------------------------------------------------------

February, 2014